﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pr1V14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] massiv = new int[30];
            int sum = 0;
            int cnt = 0;
            Random rand = new Random();
            for (int i = 0; i < massiv.Length; i++)
            {
                massiv[i] = rand.Next(20);
            }
            Console.WriteLine("Массив чисел содержит числа: ");
            for (int i = 0; i < massiv.Length; i++)
            {
                Console.Write($"{massiv[i]} ");
            }
            Console.WriteLine();
            for (int i = 0; i < massiv.Length; i++)
            {
                if (Math.Abs(massiv[i]) < (i+1) * (i+1))
                {
                   sum = sum + massiv[i];
                    cnt++;
                }
                
            }
            Console.WriteLine($"Сумма элементов |a\u2081|<i*i равняется: {sum}, их количество: {cnt}");
            Console.ReadKey();
                
        }
    }
}
